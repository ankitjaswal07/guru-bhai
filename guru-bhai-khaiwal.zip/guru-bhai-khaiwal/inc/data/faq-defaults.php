<?php
defined('ABSPATH')||exit;
return array(
 array('question'=>'Where can I see today’s and yesterday’s results?','answer'=>'Both days appear together on the homepage and results page.','active'=>1),
 array('question'=>'How do I open an older chart?','answer'=>'On the chart page, select a game, month and year using the filters.','active'=>1),
 array('question'=>'Why do some dates show a dash?','answer'=>'A dash means no published record is available. It does not mean zero.','active'=>1),
 array('question'=>'Which timezone is used?','answer'=>'Times follow the timezone configured for this WordPress site. A new day begins at local midnight.','active'=>1),
 array('question'=>'Can I place bets or make payments here?','answer'=>'No. This website provides information only. We do not offer wagers, deposits or payment services.','active'=>1),
 array('question'=>'How can I request a correction?','answer'=>'Contact us with the game name, date and the record you would like us to review.','active'=>1),
);
